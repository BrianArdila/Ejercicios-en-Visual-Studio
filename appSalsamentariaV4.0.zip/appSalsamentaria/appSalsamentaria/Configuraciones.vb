﻿Public Class Configuraciones
    Dim Form_Hijo As Form 'Carga los Forms anidados
    ''' <summary>
    ''' Abre los From como hijos del panel principal
    ''' </summary>
    ''' <param name="formHijo"></param>
    Sub AbrirFormInPanel(formHijo As Object)
        ' Igualamos la variable al parametro
        Form_Hijo = formHijo
        'Pregunta si el panelcontrolador tiene valor mayor que cero
        If Me.PlContenedor.Controls.Count > 0 Then
            'RTA Si entonses quita el control de la ubicacion
            Me.PlContenedor.Controls.RemoveAt(0)
        End If
        'Ajustamos el from a el panel
        Form_Hijo.TopLevel = False
        Form_Hijo.FormBorderStyle = FormBorderStyle.None
        Form_Hijo.Dock = DockStyle.Fill
        'Añadimos el  From a el panel
        Me.PlContenedor.Controls.Add(Form_Hijo)
        ' Obtenermos los datos del From
        Me.PlContenedor.Tag = Form_Hijo
        'Muestra el From
        Form_Hijo.Show()
    End Sub
    ''' <summary>
    ''' Abrimos el form temas
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub CambioTemaBTT_Click(sender As Object, e As EventArgs) Handles CambioTemaBTT.Click
        AbrirFormInPanel(New Temas)
    End Sub
    ''' <summary>
    ''' Abrimos el form Hora
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub HoraBTT_Click(sender As Object, e As EventArgs) Handles HoraBTT.Click

        AbrirFormInPanel(New Hora)
    End Sub
    ''' <summary>
    ''' Abrimos el form Informacion de contacto
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub InfoContactoBTT_Click(sender As Object, e As EventArgs) Handles InfoContactoBTT.Click
        AbrirFormInPanel(New InfoContacto)

    End Sub
    ''' <summary>
    ''' Restaura la aplicacion a modo fabrica
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub RestaurarBTT_Click(sender As Object, e As EventArgs) Handles RestaurarBTT.Click

    End Sub

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Configuraciones_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AbrirFormInPanel(New Temas)
    End Sub
End Class