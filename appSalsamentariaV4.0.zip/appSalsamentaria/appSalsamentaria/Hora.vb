﻿Public Class Hora

End Class