﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Inventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Tipo_ProductoLabel As System.Windows.Forms.Label
        Dim IvaLabel As System.Windows.Forms.Label
        Dim Referencia_ProductoLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim ActivoLabel As System.Windows.Forms.Label
        Dim DescripciónLabel As System.Windows.Forms.Label
        Dim Vlr_CompraLabel As System.Windows.Forms.Label
        Dim Precio_VentaLabel As System.Windows.Forms.Label
        Dim Fecha_IngresoLabel As System.Windows.Forms.Label
        Dim Venta_PesoLabel As System.Windows.Forms.Label
        Dim CantidadLabel As System.Windows.Forms.Label
        Me.Tipo_ProductoTextBox = New System.Windows.Forms.TextBox()
        Me.CategoriaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BDD_Salsamentaria_1DataSet = New appSalsamentaria.BDD_Salsamentaria_1DataSet()
        Me.IvaTextBox = New System.Windows.Forms.TextBox()
        Me.Referencia_ProductoTextBox = New System.Windows.Forms.TextBox()
        Me.InventarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.NombreTextBox = New System.Windows.Forms.TextBox()
        Me.ActivoCheckBox = New System.Windows.Forms.CheckBox()
        Me.DescripciónTextBox = New System.Windows.Forms.TextBox()
        Me.Vlr_CompraTextBox = New System.Windows.Forms.TextBox()
        Me.Precio_VentaTextBox = New System.Windows.Forms.TextBox()
        Me.Fecha_IngresoDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Venta_PesoCheckBox = New System.Windows.Forms.CheckBox()
        Me.CantidadTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.InventarioDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn1 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewCheckBoxColumn2 = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SalsaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Carne_FriaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.QuesoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LacteoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Parte_PolloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PolloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.InventarioTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.InventarioTableAdapter()
        Me.TableAdapterManager = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager()
        Me.CategoriaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.CategoriaTableAdapter()
        Me.PolloTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.PolloTableAdapter()
        Me.Parte_PolloTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.Parte_PolloTableAdapter()
        Me.LacteoTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.LacteoTableAdapter()
        Me.QuesoTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.QuesoTableAdapter()
        Me.Carne_FriaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.Carne_FriaTableAdapter()
        Me.SalsaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.SalsaTableAdapter()
        Me.ActualizarBTT = New System.Windows.Forms.Button()
        Me.BuscarBTT = New System.Windows.Forms.Button()
        Me.ModificarBTT = New System.Windows.Forms.Button()
        Me.EliminarBTT = New System.Windows.Forms.Button()
        Me.AgregarBTT = New System.Windows.Forms.Button()
        Me.VolverBTT = New System.Windows.Forms.Button()
        Tipo_ProductoLabel = New System.Windows.Forms.Label()
        IvaLabel = New System.Windows.Forms.Label()
        Referencia_ProductoLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        ActivoLabel = New System.Windows.Forms.Label()
        DescripciónLabel = New System.Windows.Forms.Label()
        Vlr_CompraLabel = New System.Windows.Forms.Label()
        Precio_VentaLabel = New System.Windows.Forms.Label()
        Fecha_IngresoLabel = New System.Windows.Forms.Label()
        Venta_PesoLabel = New System.Windows.Forms.Label()
        CantidadLabel = New System.Windows.Forms.Label()
        CType(Me.CategoriaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BDD_Salsamentaria_1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.InventarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.InventarioDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SalsaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Carne_FriaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.QuesoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LacteoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Parte_PolloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PolloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Tipo_ProductoLabel
        '
        Tipo_ProductoLabel.AutoSize = True
        Tipo_ProductoLabel.Location = New System.Drawing.Point(7, 26)
        Tipo_ProductoLabel.Name = "Tipo_ProductoLabel"
        Tipo_ProductoLabel.Size = New System.Drawing.Size(77, 13)
        Tipo_ProductoLabel.TabIndex = 10
        Tipo_ProductoLabel.Text = "Tipo Producto:"
        '
        'IvaLabel
        '
        IvaLabel.AutoSize = True
        IvaLabel.Location = New System.Drawing.Point(7, 52)
        IvaLabel.Name = "IvaLabel"
        IvaLabel.Size = New System.Drawing.Size(25, 13)
        IvaLabel.TabIndex = 12
        IvaLabel.Text = "Iva:"
        '
        'Referencia_ProductoLabel
        '
        Referencia_ProductoLabel.AutoSize = True
        Referencia_ProductoLabel.Location = New System.Drawing.Point(9, 20)
        Referencia_ProductoLabel.Name = "Referencia_ProductoLabel"
        Referencia_ProductoLabel.Size = New System.Drawing.Size(108, 13)
        Referencia_ProductoLabel.TabIndex = 24
        Referencia_ProductoLabel.Text = "Referencia Producto:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Location = New System.Drawing.Point(9, 46)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(47, 13)
        NombreLabel.TabIndex = 26
        NombreLabel.Text = "Nombre:"
        '
        'ActivoLabel
        '
        ActivoLabel.AutoSize = True
        ActivoLabel.Location = New System.Drawing.Point(9, 74)
        ActivoLabel.Name = "ActivoLabel"
        ActivoLabel.Size = New System.Drawing.Size(40, 13)
        ActivoLabel.TabIndex = 28
        ActivoLabel.Text = "Activo:"
        '
        'DescripciónLabel
        '
        DescripciónLabel.AutoSize = True
        DescripciónLabel.Location = New System.Drawing.Point(9, 102)
        DescripciónLabel.Name = "DescripciónLabel"
        DescripciónLabel.Size = New System.Drawing.Size(66, 13)
        DescripciónLabel.TabIndex = 30
        DescripciónLabel.Text = "Descripción:"
        '
        'Vlr_CompraLabel
        '
        Vlr_CompraLabel.AutoSize = True
        Vlr_CompraLabel.Location = New System.Drawing.Point(9, 128)
        Vlr_CompraLabel.Name = "Vlr_CompraLabel"
        Vlr_CompraLabel.Size = New System.Drawing.Size(60, 13)
        Vlr_CompraLabel.TabIndex = 32
        Vlr_CompraLabel.Text = "vlr Compra:"
        '
        'Precio_VentaLabel
        '
        Precio_VentaLabel.AutoSize = True
        Precio_VentaLabel.Location = New System.Drawing.Point(9, 154)
        Precio_VentaLabel.Name = "Precio_VentaLabel"
        Precio_VentaLabel.Size = New System.Drawing.Size(71, 13)
        Precio_VentaLabel.TabIndex = 34
        Precio_VentaLabel.Text = "Precio Venta:"
        '
        'Fecha_IngresoLabel
        '
        Fecha_IngresoLabel.AutoSize = True
        Fecha_IngresoLabel.Location = New System.Drawing.Point(9, 181)
        Fecha_IngresoLabel.Name = "Fecha_IngresoLabel"
        Fecha_IngresoLabel.Size = New System.Drawing.Size(78, 13)
        Fecha_IngresoLabel.TabIndex = 38
        Fecha_IngresoLabel.Text = "Fecha Ingreso:"
        '
        'Venta_PesoLabel
        '
        Venta_PesoLabel.AutoSize = True
        Venta_PesoLabel.Location = New System.Drawing.Point(9, 208)
        Venta_PesoLabel.Name = "Venta_PesoLabel"
        Venta_PesoLabel.Size = New System.Drawing.Size(65, 13)
        Venta_PesoLabel.TabIndex = 40
        Venta_PesoLabel.Text = "Venta Peso:"
        '
        'CantidadLabel
        '
        CantidadLabel.AutoSize = True
        CantidadLabel.Location = New System.Drawing.Point(9, 236)
        CantidadLabel.Name = "CantidadLabel"
        CantidadLabel.Size = New System.Drawing.Size(52, 13)
        CantidadLabel.TabIndex = 42
        CantidadLabel.Text = "Cantidad:"
        '
        'Tipo_ProductoTextBox
        '
        Me.Tipo_ProductoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CategoriaBindingSource, "Tipo_Producto", True))
        Me.Tipo_ProductoTextBox.Location = New System.Drawing.Point(90, 23)
        Me.Tipo_ProductoTextBox.Name = "Tipo_ProductoTextBox"
        Me.Tipo_ProductoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_ProductoTextBox.TabIndex = 11
        '
        'CategoriaBindingSource
        '
        Me.CategoriaBindingSource.DataMember = "Categoria"
        Me.CategoriaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'BDD_Salsamentaria_1DataSet
        '
        Me.BDD_Salsamentaria_1DataSet.DataSetName = "BDD_Salsamentaria_1DataSet"
        Me.BDD_Salsamentaria_1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'IvaTextBox
        '
        Me.IvaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CategoriaBindingSource, "Iva", True))
        Me.IvaTextBox.Location = New System.Drawing.Point(90, 49)
        Me.IvaTextBox.Name = "IvaTextBox"
        Me.IvaTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IvaTextBox.TabIndex = 13
        '
        'Referencia_ProductoTextBox
        '
        Me.Referencia_ProductoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Referencia_Producto", True))
        Me.Referencia_ProductoTextBox.Location = New System.Drawing.Point(123, 17)
        Me.Referencia_ProductoTextBox.Name = "Referencia_ProductoTextBox"
        Me.Referencia_ProductoTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Referencia_ProductoTextBox.TabIndex = 25
        '
        'InventarioBindingSource
        '
        Me.InventarioBindingSource.DataMember = "Inventario"
        Me.InventarioBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'NombreTextBox
        '
        Me.NombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Nombre", True))
        Me.NombreTextBox.Location = New System.Drawing.Point(123, 43)
        Me.NombreTextBox.Name = "NombreTextBox"
        Me.NombreTextBox.Size = New System.Drawing.Size(200, 20)
        Me.NombreTextBox.TabIndex = 27
        '
        'ActivoCheckBox
        '
        Me.ActivoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.InventarioBindingSource, "Activo", True))
        Me.ActivoCheckBox.Location = New System.Drawing.Point(123, 69)
        Me.ActivoCheckBox.Name = "ActivoCheckBox"
        Me.ActivoCheckBox.Size = New System.Drawing.Size(200, 24)
        Me.ActivoCheckBox.TabIndex = 29
        Me.ActivoCheckBox.UseVisualStyleBackColor = True
        '
        'DescripciónTextBox
        '
        Me.DescripciónTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Descripción", True))
        Me.DescripciónTextBox.Location = New System.Drawing.Point(123, 99)
        Me.DescripciónTextBox.Name = "DescripciónTextBox"
        Me.DescripciónTextBox.Size = New System.Drawing.Size(200, 20)
        Me.DescripciónTextBox.TabIndex = 31
        '
        'Vlr_CompraTextBox
        '
        Me.Vlr_CompraTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "vlr_Compra", True))
        Me.Vlr_CompraTextBox.Location = New System.Drawing.Point(123, 125)
        Me.Vlr_CompraTextBox.Name = "Vlr_CompraTextBox"
        Me.Vlr_CompraTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Vlr_CompraTextBox.TabIndex = 33
        '
        'Precio_VentaTextBox
        '
        Me.Precio_VentaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Precio_Venta", True))
        Me.Precio_VentaTextBox.Location = New System.Drawing.Point(123, 151)
        Me.Precio_VentaTextBox.Name = "Precio_VentaTextBox"
        Me.Precio_VentaTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Precio_VentaTextBox.TabIndex = 35
        '
        'Fecha_IngresoDateTimePicker
        '
        Me.Fecha_IngresoDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.InventarioBindingSource, "Fecha_Ingreso", True))
        Me.Fecha_IngresoDateTimePicker.Location = New System.Drawing.Point(123, 177)
        Me.Fecha_IngresoDateTimePicker.Name = "Fecha_IngresoDateTimePicker"
        Me.Fecha_IngresoDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Fecha_IngresoDateTimePicker.TabIndex = 39
        '
        'Venta_PesoCheckBox
        '
        Me.Venta_PesoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.InventarioBindingSource, "Venta_Peso", True))
        Me.Venta_PesoCheckBox.Location = New System.Drawing.Point(123, 203)
        Me.Venta_PesoCheckBox.Name = "Venta_PesoCheckBox"
        Me.Venta_PesoCheckBox.Size = New System.Drawing.Size(200, 24)
        Me.Venta_PesoCheckBox.TabIndex = 41
        Me.Venta_PesoCheckBox.UseVisualStyleBackColor = True
        '
        'CantidadTextBox
        '
        Me.CantidadTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Cantidad", True))
        Me.CantidadTextBox.Location = New System.Drawing.Point(123, 233)
        Me.CantidadTextBox.Name = "CantidadTextBox"
        Me.CantidadTextBox.Size = New System.Drawing.Size(200, 20)
        Me.CantidadTextBox.TabIndex = 43
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Referencia_ProductoLabel)
        Me.GroupBox1.Controls.Add(Me.Referencia_ProductoTextBox)
        Me.GroupBox1.Controls.Add(NombreLabel)
        Me.GroupBox1.Controls.Add(Me.NombreTextBox)
        Me.GroupBox1.Controls.Add(ActivoLabel)
        Me.GroupBox1.Controls.Add(Me.ActivoCheckBox)
        Me.GroupBox1.Controls.Add(DescripciónLabel)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.DescripciónTextBox)
        Me.GroupBox1.Controls.Add(Vlr_CompraLabel)
        Me.GroupBox1.Controls.Add(Me.Vlr_CompraTextBox)
        Me.GroupBox1.Controls.Add(Precio_VentaLabel)
        Me.GroupBox1.Controls.Add(Me.Precio_VentaTextBox)
        Me.GroupBox1.Controls.Add(Fecha_IngresoLabel)
        Me.GroupBox1.Controls.Add(Me.Fecha_IngresoDateTimePicker)
        Me.GroupBox1.Controls.Add(Venta_PesoLabel)
        Me.GroupBox1.Controls.Add(Me.Venta_PesoCheckBox)
        Me.GroupBox1.Controls.Add(CantidadLabel)
        Me.GroupBox1.Controls.Add(Me.CantidadTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(650, 283)
        Me.GroupBox1.TabIndex = 49
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Inventario"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Tipo_ProductoLabel)
        Me.GroupBox2.Controls.Add(Me.Tipo_ProductoTextBox)
        Me.GroupBox2.Controls.Add(IvaLabel)
        Me.GroupBox2.Controls.Add(Me.IvaTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(395, 19)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(227, 80)
        Me.GroupBox2.TabIndex = 50
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Categoria"
        '
        'InventarioDataGridView
        '
        Me.InventarioDataGridView.AutoGenerateColumns = False
        Me.InventarioDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.InventarioDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewCheckBoxColumn1, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewCheckBoxColumn2, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn8})
        Me.InventarioDataGridView.DataSource = Me.InventarioBindingSource
        Me.InventarioDataGridView.Location = New System.Drawing.Point(12, 320)
        Me.InventarioDataGridView.Name = "InventarioDataGridView"
        Me.InventarioDataGridView.Size = New System.Drawing.Size(1119, 349)
        Me.InventarioDataGridView.TabIndex = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Referencia_Producto"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Referencia_Producto"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 150
        '
        'DataGridViewCheckBoxColumn1
        '
        Me.DataGridViewCheckBoxColumn1.DataPropertyName = "Activo"
        Me.DataGridViewCheckBoxColumn1.HeaderText = "Activo"
        Me.DataGridViewCheckBoxColumn1.Name = "DataGridViewCheckBoxColumn1"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Descripción"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Descripción"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 200
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "vlr_Compra"
        Me.DataGridViewTextBoxColumn5.HeaderText = "vlr_Compra"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Precio_Venta"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Precio_Venta"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewCheckBoxColumn2
        '
        Me.DataGridViewCheckBoxColumn2.DataPropertyName = "Venta_Peso"
        Me.DataGridViewCheckBoxColumn2.HeaderText = "Venta_Peso"
        Me.DataGridViewCheckBoxColumn2.Name = "DataGridViewCheckBoxColumn2"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Cantidad"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Cantidad"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Fecha_Ingreso"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Fecha_Ingreso"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'SalsaBindingSource
        '
        Me.SalsaBindingSource.DataMember = "Salsa"
        Me.SalsaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'Carne_FriaBindingSource
        '
        Me.Carne_FriaBindingSource.DataMember = "Carne_Fria"
        Me.Carne_FriaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'QuesoBindingSource
        '
        Me.QuesoBindingSource.DataMember = "Queso"
        Me.QuesoBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'LacteoBindingSource
        '
        Me.LacteoBindingSource.DataMember = "Lacteo"
        Me.LacteoBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'Parte_PolloBindingSource
        '
        Me.Parte_PolloBindingSource.DataMember = "Parte_Pollo"
        Me.Parte_PolloBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'PolloBindingSource
        '
        Me.PolloBindingSource.DataMember = "Pollo"
        Me.PolloBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'InventarioTableAdapter
        '
        Me.InventarioTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Carne_FriaTableAdapter = Nothing
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.Detalles_PedidoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.Inventario_ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.InventarioTableAdapter = Me.InventarioTableAdapter
        Me.TableAdapterManager.LacteoTableAdapter = Nothing
        Me.TableAdapterManager.Parte_PolloTableAdapter = Nothing
        Me.TableAdapterManager.PolloTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.QuesoTableAdapter = Nothing
        Me.TableAdapterManager.RolTableAdapter = Nothing
        Me.TableAdapterManager.SalsaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Usuario_RolTableAdapter = Nothing
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'CategoriaTableAdapter
        '
        Me.CategoriaTableAdapter.ClearBeforeFill = True
        '
        'PolloTableAdapter
        '
        Me.PolloTableAdapter.ClearBeforeFill = True
        '
        'Parte_PolloTableAdapter
        '
        Me.Parte_PolloTableAdapter.ClearBeforeFill = True
        '
        'LacteoTableAdapter
        '
        Me.LacteoTableAdapter.ClearBeforeFill = True
        '
        'QuesoTableAdapter
        '
        Me.QuesoTableAdapter.ClearBeforeFill = True
        '
        'Carne_FriaTableAdapter
        '
        Me.Carne_FriaTableAdapter.ClearBeforeFill = True
        '
        'SalsaTableAdapter
        '
        Me.SalsaTableAdapter.ClearBeforeFill = True
        '
        'ActualizarBTT
        '
        Me.ActualizarBTT.Location = New System.Drawing.Point(1016, 183)
        Me.ActualizarBTT.Name = "ActualizarBTT"
        Me.ActualizarBTT.Size = New System.Drawing.Size(115, 36)
        Me.ActualizarBTT.TabIndex = 56
        Me.ActualizarBTT.Text = "Actualizar"
        Me.ActualizarBTT.UseVisualStyleBackColor = True
        '
        'BuscarBTT
        '
        Me.BuscarBTT.Location = New System.Drawing.Point(827, 182)
        Me.BuscarBTT.Name = "BuscarBTT"
        Me.BuscarBTT.Size = New System.Drawing.Size(115, 36)
        Me.BuscarBTT.TabIndex = 55
        Me.BuscarBTT.Text = "Buscar"
        Me.BuscarBTT.UseVisualStyleBackColor = True
        '
        'ModificarBTT
        '
        Me.ModificarBTT.Location = New System.Drawing.Point(827, 112)
        Me.ModificarBTT.Name = "ModificarBTT"
        Me.ModificarBTT.Size = New System.Drawing.Size(115, 36)
        Me.ModificarBTT.TabIndex = 54
        Me.ModificarBTT.Text = "Modificar"
        Me.ModificarBTT.UseVisualStyleBackColor = True
        '
        'EliminarBTT
        '
        Me.EliminarBTT.Location = New System.Drawing.Point(668, 182)
        Me.EliminarBTT.Name = "EliminarBTT"
        Me.EliminarBTT.Size = New System.Drawing.Size(115, 36)
        Me.EliminarBTT.TabIndex = 53
        Me.EliminarBTT.Text = "Eliminar"
        Me.EliminarBTT.UseVisualStyleBackColor = True
        '
        'AgregarBTT
        '
        Me.AgregarBTT.Location = New System.Drawing.Point(668, 109)
        Me.AgregarBTT.Name = "AgregarBTT"
        Me.AgregarBTT.Size = New System.Drawing.Size(115, 36)
        Me.AgregarBTT.TabIndex = 52
        Me.AgregarBTT.Text = "Agregar"
        Me.AgregarBTT.UseVisualStyleBackColor = True
        '
        'VolverBTT
        '
        Me.VolverBTT.Location = New System.Drawing.Point(1016, 253)
        Me.VolverBTT.Name = "VolverBTT"
        Me.VolverBTT.Size = New System.Drawing.Size(115, 36)
        Me.VolverBTT.TabIndex = 51
        Me.VolverBTT.Text = "Volver"
        Me.VolverBTT.UseVisualStyleBackColor = True
        '
        'Inventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1152, 681)
        Me.Controls.Add(Me.ActualizarBTT)
        Me.Controls.Add(Me.BuscarBTT)
        Me.Controls.Add(Me.ModificarBTT)
        Me.Controls.Add(Me.EliminarBTT)
        Me.Controls.Add(Me.AgregarBTT)
        Me.Controls.Add(Me.VolverBTT)
        Me.Controls.Add(Me.InventarioDataGridView)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Inventario"
        Me.Text = "Inventario"
        CType(Me.CategoriaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BDD_Salsamentaria_1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.InventarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.InventarioDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SalsaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Carne_FriaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.QuesoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LacteoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Parte_PolloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PolloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BDD_Salsamentaria_1DataSet As BDD_Salsamentaria_1DataSet
    Friend WithEvents InventarioBindingSource As BindingSource
    Friend WithEvents InventarioTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.InventarioTableAdapter
    Friend WithEvents TableAdapterManager As BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents CategoriaBindingSource As BindingSource
    Friend WithEvents CategoriaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.CategoriaTableAdapter
    Friend WithEvents PolloBindingSource As BindingSource
    Friend WithEvents PolloTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.PolloTableAdapter
    Friend WithEvents Tipo_ProductoTextBox As TextBox
    Friend WithEvents IvaTextBox As TextBox
    Friend WithEvents Referencia_ProductoTextBox As TextBox
    Friend WithEvents NombreTextBox As TextBox
    Friend WithEvents ActivoCheckBox As CheckBox
    Friend WithEvents DescripciónTextBox As TextBox
    Friend WithEvents Vlr_CompraTextBox As TextBox
    Friend WithEvents Precio_VentaTextBox As TextBox
    Friend WithEvents Fecha_IngresoDateTimePicker As DateTimePicker
    Friend WithEvents Venta_PesoCheckBox As CheckBox
    Friend WithEvents CantidadTextBox As TextBox
    Friend WithEvents Parte_PolloBindingSource As BindingSource
    Friend WithEvents Parte_PolloTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.Parte_PolloTableAdapter
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LacteoBindingSource As BindingSource
    Friend WithEvents LacteoTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.LacteoTableAdapter
    Friend WithEvents QuesoBindingSource As BindingSource
    Friend WithEvents QuesoTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.QuesoTableAdapter
    Friend WithEvents Carne_FriaBindingSource As BindingSource
    Friend WithEvents Carne_FriaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.Carne_FriaTableAdapter
    Friend WithEvents SalsaBindingSource As BindingSource
    Friend WithEvents SalsaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.SalsaTableAdapter
    Friend WithEvents InventarioDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn1 As DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewCheckBoxColumn2 As DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents ActualizarBTT As Button
    Friend WithEvents BuscarBTT As Button
    Friend WithEvents ModificarBTT As Button
    Friend WithEvents EliminarBTT As Button
    Friend WithEvents AgregarBTT As Button
    Friend WithEvents VolverBTT As Button
End Class
