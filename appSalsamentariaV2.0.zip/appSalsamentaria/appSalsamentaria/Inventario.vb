﻿Public Class Inventario
    Private Sub Inventario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Salsa' 
        Me.SalsaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Salsa)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Salsa'
        Me.SalsaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Salsa)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Carne_Fria' 
        Me.Carne_FriaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Carne_Fria)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Queso' 
        Me.QuesoTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Queso)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Lacteo'
        Me.LacteoTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Lacteo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Parte_Pollo' 
        Me.Parte_PolloTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Parte_Pollo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Pollo' 
        Me.PolloTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Pollo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Categoria' 
        Me.CategoriaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Categoria)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Inventario' 
        Me.InventarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Inventario)

    End Sub

    Private Sub AgregarBTT_Click(sender As Object, e As EventArgs) Handles AgregarBTT.Click

    End Sub
End Class