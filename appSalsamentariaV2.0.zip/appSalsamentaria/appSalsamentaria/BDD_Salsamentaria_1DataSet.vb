﻿

Partial Public Class BDD_Salsamentaria_1DataSet
    Friend ReadOnly UsuarioBindingSource As Object
End Class


Partial Public Class BDD_Salsamentaria_1DataSet
End Class
