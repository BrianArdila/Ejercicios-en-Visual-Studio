﻿Public Class Inventario
    Private Sub Inventario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Salsa' Puede moverla o quitarla según sea necesario.
        Me.SalsaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Salsa)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Salsa' Puede moverla o quitarla según sea necesario.
        Me.SalsaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Salsa)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Carne_Fria' Puede moverla o quitarla según sea necesario.
        Me.Carne_FriaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Carne_Fria)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Queso' Puede moverla o quitarla según sea necesario.
        Me.QuesoTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Queso)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Lacteo' Puede moverla o quitarla según sea necesario.
        Me.LacteoTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Lacteo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Parte_Pollo' Puede moverla o quitarla según sea necesario.
        Me.Parte_PolloTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Parte_Pollo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Pollo' Puede moverla o quitarla según sea necesario.
        Me.PolloTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Pollo)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Categoria' Puede moverla o quitarla según sea necesario.
        Me.CategoriaTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Categoria)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Inventario' Puede moverla o quitarla según sea necesario.
        Me.InventarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Inventario)

    End Sub
End Class