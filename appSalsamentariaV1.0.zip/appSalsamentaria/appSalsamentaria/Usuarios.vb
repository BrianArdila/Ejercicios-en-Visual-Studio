﻿Public Class Usuarios
    ''' <summary>
    ''' Regresa a el panel principal
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub VolverBTT_Click(sender As Object, e As EventArgs) Handles VolverBTT.Click
        'Abre el form de panel principal
        Panel_Principal.Show()
        'Cierra la ventana actual
        Me.Close()
    End Sub
    ''' <summary>
    ''' Actualiza los datos de la tabla usuario y mantiene los textboxs vacios
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ActualizarBTT_Click(sender As Object, e As EventArgs) Handles ActualizarBTT.Click
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario_Rol'
        Me.Usuario_RolTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario_Rol)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
        Me.UsuarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario)
        'Carga los textbox sin texto
        NombreTextBox.Text = ""
        ApellidoTextBox.Text = ""
        CedulaTextBox.Text = ""
        TelefonoTextBox.Text = ""
        CorreoTextBox.Text = ""
        ContraseñaTextBox.Text = ""
    End Sub
    ''' <summary>
    ''' carga datos en la tabla y los textboxs vacios al cargar el form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub Usuarios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario_Rol'
        Me.Usuario_RolTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario_Rol)
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
        Me.UsuarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario)
        'Carga los textbox sin texto
        NombreTextBox.Text = ""
        ApellidoTextBox.Text = ""
        CedulaTextBox.Text = ""
        TelefonoTextBox.Text = ""
        CorreoTextBox.Text = ""
        ContraseñaTextBox.Text = ""
    End Sub
    ''' <summary>
    ''' Inserta datos nuevos a la tabla
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub AgregarBTT_Click(sender As Object, e As EventArgs) Handles AgregarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Agregar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos a la tabla usuario
                Me.UsuarioTableAdapter.Insert(NombreTextBox.Text, ApellidoTextBox.Text, CedulaTextBox.Text, TelefonoTextBox.Text, CorreoTextBox.Text, ContraseñaTextBox.Text, Fecha_IngresoDateTimePicker.Value.ToString("dd/MM/yyyy"))
                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.UsuarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario)
                'Mueve el apuntador del Datagridview a la ultima fila
                Dim Columna As Integer = 0
                Dim Fila As Integer = Me.UsuarioDataGridView.Rows.Count
                Me.UsuarioDataGridView.CurrentCell = Me.UsuarioDataGridView(Columna, (Fila - 2))
                'Valida que tipo de cargo tiene
                If CargoComboBox.Text = "Administrador" Then
                    ' Ingresa datos la tabla Usuario_Rol
                    Me.Usuario_RolTableAdapter.Insert(IdTextBox.Text, 1)
                Else
                    ' Ingresa datos la tabla Usuario_Rol
                    Me.Usuario_RolTableAdapter.Insert(IdTextBox.Text, 2)
                End If
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
                TelefonoTextBox.Text = ""
                CorreoTextBox.Text = ""
                ContraseñaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Elimina una fila de la tabla 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub EliminarBTT_Click(sender As Object, e As EventArgs) Handles EliminarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Eliminar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos a la tabla usuario(Busca a el dato)
                Me.UsuarioTableAdapter.Buscar_Datos(Me.BDD_Salsamentaria_1DataSet.Usuario, CedulaTextBox.Text)
                'Elimina los datos de las tablas usuario y usuario_rol
                Me.Usuario_RolTableAdapter.DeleteQuery(IdTextBox.Text)
                Me.UsuarioTableAdapter.DeleteQuery(CedulaTextBox.Text)

                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.UsuarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario)
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
                TelefonoTextBox.Text = ""
                CorreoTextBox.Text = ""
                ContraseñaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Busca datos por medio de la cedula
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BuscarBTT_Click(sender As Object, e As EventArgs) Handles BuscarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Buscar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'Busaca el dato en las tablas
                'consulta a la base de datos para la tabla usuario
                Me.UsuarioTableAdapter.Buscar_Datos(Me.BDD_Salsamentaria_1DataSet.Usuario, CedulaTextBox.Text)
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Modifica datos de la tabla 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ModificarBTT_Click(sender As Object, e As EventArgs) Handles ModificarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Modificar un registro debes ingresar la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos 
                Me.UsuarioTableAdapter.Actualizar_Datos(NombreTextBox.Text, ApellidoTextBox.Text, CedulaTextBox.Text, TelefonoTextBox.Text, CorreoTextBox.Text, ContraseñaTextBox.Text, Fecha_IngresoDateTimePicker.Value.ToString("MM/dd/yyyy"), CedulaTextBox.Text)
                'Valida que tipo de cargo tiene
                If CargoComboBox.Text = "Administrador" Then
                    ' Ingresa datos la tabla Usuario_Rol
                    Me.Usuario_RolTableAdapter.UpdateQuery(IdTextBox.Text, 1, IdTextBox.Text)
                Else
                    ' Ingresa datos la tabla Usuario_Rol
                    Me.Usuario_RolTableAdapter.UpdateQuery(IdTextBox.Text, 2, IdTextBox.Text)
                End If
                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.UsuarioTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Usuario)
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
                TelefonoTextBox.Text = ""
                CorreoTextBox.Text = ""
                ContraseñaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub

End Class