﻿Public Class Cliente
    ''' <summary>
    ''' Regresa a el panel principal
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub VolverBTT_Click(sender As Object, e As EventArgs) Handles VolverBTT.Click
        'Abre el form de panel principal
        Panel_Principal.Show()
        'Cierra la ventana actual
        Me.Close()
    End Sub
    ''' <summary>
    ''' Actualiza los datos de la tabla usuario y mantiene los textboxs vacios
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ActualizarBTT_Click(sender As Object, e As EventArgs) Handles ActualizarBTT.Click
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
        Me.ClienteTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Cliente)
        'Carga los textbox sin texto
        NombreTextBox.Text = ""
        ApellidoTextBox.Text = ""
        CedulaTextBox.Text = ""
    End Sub
    Private Sub Cliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Cliente' 
        Me.ClienteTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Cliente)
        'Carga los textbox sin texto
        NombreTextBox.Text = ""
        ApellidoTextBox.Text = ""
        CedulaTextBox.Text = ""

    End Sub
    ''' <summary>
    ''' Inserta datos nuevos a la tabla
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub AgregarBTT_Click(sender As Object, e As EventArgs) Handles AgregarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Agregar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos 
                Me.ClienteTableAdapter.Insert(NombreTextBox.Text, ApellidoTextBox.Text, CedulaTextBox.Text, Fecha_IngresoDateTimePicker.Value.ToString("dd/MM/yyyy"))
                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.ClienteTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Cliente)
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Elimina una fila de la tabla 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub EliminarBTT_Click(sender As Object, e As EventArgs) Handles EliminarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Eliminar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos 
                Me.ClienteTableAdapter.DeleteQuery(CedulaTextBox.Text)
                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.ClienteTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Cliente)
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Busca datos por medio de la cedula
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub BuscarBTT_Click(sender As Object, e As EventArgs) Handles BuscarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Buscar un registro debes ingresar primero la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos 
                Me.ClienteTableAdapter.Buscar_Datos(Me.BDD_Salsamentaria_1DataSet.Cliente, CedulaTextBox.Text)
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
    ''' <summary>
    ''' Modifica datos de la tabla 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ModificarBTT_Click(sender As Object, e As EventArgs) Handles ModificarBTT.Click
        Try
            'Comprueba si cedula textbox contiene datos
            If CedulaTextBox.Text = "" Then
                'Mensaje de Ayuda
                MsgBox("Para poder Modificar un registro debes ingresar la cedula del usuario", MsgBoxStyle.Exclamation)
            Else
                'consulta a la base de datos 
                Me.ClienteTableAdapter.Actualizar_Datos(NombreTextBox.Text, ApellidoTextBox.Text, CedulaTextBox.Text, CedulaTextBox.Text)
                'TODO: esta línea de código carga datos en la tabla 'BDD_Salsamentaria_1DataSet.Usuario
                Me.ClienteTableAdapter.Fill(Me.BDD_Salsamentaria_1DataSet.Cliente)
                'Carga los textbox sin texto
                NombreTextBox.Text = ""
                ApellidoTextBox.Text = ""
                CedulaTextBox.Text = ""
            End If
        Catch ex As Exception ' ex es la variable que controla las excepciones(errores)
            'Mensaje de Ayuda
            MsgBox(ex.Message)
        End Try
    End Sub
End Class