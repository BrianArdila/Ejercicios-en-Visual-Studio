﻿Public Class Factura

End Class