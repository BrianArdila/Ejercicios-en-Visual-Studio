﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Panel_Principal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.UsuariosBTT = New System.Windows.Forms.Button()
        Me.InventarioBTT = New System.Windows.Forms.Button()
        Me.ProveedorBTT = New System.Windows.Forms.Button()
        Me.ClienteBTT = New System.Windows.Forms.Button()
        Me.FacturaBTT = New System.Windows.Forms.Button()
        Me.SalirBTT = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'UsuariosBTT
        '
        Me.UsuariosBTT.Location = New System.Drawing.Point(119, 45)
        Me.UsuariosBTT.Name = "UsuariosBTT"
        Me.UsuariosBTT.Size = New System.Drawing.Size(153, 46)
        Me.UsuariosBTT.TabIndex = 0
        Me.UsuariosBTT.Text = "Usuarios"
        Me.UsuariosBTT.UseVisualStyleBackColor = True
        '
        'InventarioBTT
        '
        Me.InventarioBTT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.InventarioBTT.Location = New System.Drawing.Point(539, 45)
        Me.InventarioBTT.Name = "InventarioBTT"
        Me.InventarioBTT.Size = New System.Drawing.Size(153, 46)
        Me.InventarioBTT.TabIndex = 1
        Me.InventarioBTT.Text = "Inventario"
        Me.InventarioBTT.UseVisualStyleBackColor = True
        '
        'ProveedorBTT
        '
        Me.ProveedorBTT.Location = New System.Drawing.Point(119, 190)
        Me.ProveedorBTT.Name = "ProveedorBTT"
        Me.ProveedorBTT.Size = New System.Drawing.Size(153, 46)
        Me.ProveedorBTT.TabIndex = 2
        Me.ProveedorBTT.Text = "Proveedor"
        Me.ProveedorBTT.UseVisualStyleBackColor = True
        '
        'ClienteBTT
        '
        Me.ClienteBTT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ClienteBTT.Location = New System.Drawing.Point(539, 190)
        Me.ClienteBTT.Name = "ClienteBTT"
        Me.ClienteBTT.Size = New System.Drawing.Size(153, 46)
        Me.ClienteBTT.TabIndex = 3
        Me.ClienteBTT.Text = "Cliente"
        Me.ClienteBTT.UseVisualStyleBackColor = True
        '
        'FacturaBTT
        '
        Me.FacturaBTT.Location = New System.Drawing.Point(119, 332)
        Me.FacturaBTT.Name = "FacturaBTT"
        Me.FacturaBTT.Size = New System.Drawing.Size(153, 46)
        Me.FacturaBTT.TabIndex = 4
        Me.FacturaBTT.Text = "Factura"
        Me.FacturaBTT.UseVisualStyleBackColor = True
        '
        'SalirBTT
        '
        Me.SalirBTT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SalirBTT.Location = New System.Drawing.Point(539, 332)
        Me.SalirBTT.Name = "SalirBTT"
        Me.SalirBTT.Size = New System.Drawing.Size(153, 46)
        Me.SalirBTT.TabIndex = 5
        Me.SalirBTT.Text = "Salir"
        Me.SalirBTT.UseVisualStyleBackColor = True
        '
        'Panel_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.SalirBTT)
        Me.Controls.Add(Me.FacturaBTT)
        Me.Controls.Add(Me.ClienteBTT)
        Me.Controls.Add(Me.ProveedorBTT)
        Me.Controls.Add(Me.InventarioBTT)
        Me.Controls.Add(Me.UsuariosBTT)
        Me.Name = "Panel_Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Panel_Principal"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents UsuariosBTT As Button
    Friend WithEvents InventarioBTT As Button
    Friend WithEvents ProveedorBTT As Button
    Friend WithEvents ClienteBTT As Button
    Friend WithEvents FacturaBTT As Button
    Friend WithEvents SalirBTT As Button
End Class
