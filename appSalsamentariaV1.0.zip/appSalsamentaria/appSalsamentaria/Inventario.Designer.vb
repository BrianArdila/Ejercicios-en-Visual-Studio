﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Inventario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ValorLabel As System.Windows.Forms.Label
        Dim Tipo_polloLabel As System.Windows.Forms.Label
        Dim Tipo_ProductoLabel As System.Windows.Forms.Label
        Dim IvaLabel As System.Windows.Forms.Label
        Dim Referencia_ProductoLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim ActivoLabel As System.Windows.Forms.Label
        Dim DescripciónLabel As System.Windows.Forms.Label
        Dim Vlr_CompraLabel As System.Windows.Forms.Label
        Dim Precio_VentaLabel As System.Windows.Forms.Label
        Dim Fecha_IngresoLabel As System.Windows.Forms.Label
        Dim Venta_PesoLabel As System.Windows.Forms.Label
        Dim CantidadLabel As System.Windows.Forms.Label
        Dim ValorLabel1 As System.Windows.Forms.Label
        Dim Nom_ParteLabel As System.Windows.Forms.Label
        Dim ValorLabel2 As System.Windows.Forms.Label
        Dim Tipo_LactLabel As System.Windows.Forms.Label
        Dim Tipo_QuesoLabel As System.Windows.Forms.Label
        Dim ValorLabel3 As System.Windows.Forms.Label
        Dim ValorLabel4 As System.Windows.Forms.Label
        Dim Tipo_CarneLabel As System.Windows.Forms.Label
        Dim ValorLabel5 As System.Windows.Forms.Label
        Dim Tipo_SalsaLabel As System.Windows.Forms.Label
        Me.BDD_Salsamentaria_1DataSet = New appSalsamentaria.BDD_Salsamentaria_1DataSet()
        Me.InventarioBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.InventarioTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.InventarioTableAdapter()
        Me.TableAdapterManager = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager()
        Me.CategoriaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CategoriaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.CategoriaTableAdapter()
        Me.PolloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PolloTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.PolloTableAdapter()
        Me.ValorTextBox = New System.Windows.Forms.TextBox()
        Me.Tipo_polloTextBox = New System.Windows.Forms.TextBox()
        Me.Tipo_ProductoTextBox = New System.Windows.Forms.TextBox()
        Me.IvaTextBox = New System.Windows.Forms.TextBox()
        Me.Referencia_ProductoTextBox = New System.Windows.Forms.TextBox()
        Me.NombreTextBox = New System.Windows.Forms.TextBox()
        Me.ActivoCheckBox = New System.Windows.Forms.CheckBox()
        Me.DescripciónTextBox = New System.Windows.Forms.TextBox()
        Me.Vlr_CompraTextBox = New System.Windows.Forms.TextBox()
        Me.Precio_VentaTextBox = New System.Windows.Forms.TextBox()
        Me.Fecha_IngresoDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.Venta_PesoCheckBox = New System.Windows.Forms.CheckBox()
        Me.CantidadTextBox = New System.Windows.Forms.TextBox()
        Me.Parte_PolloBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Parte_PolloTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.Parte_PolloTableAdapter()
        Me.ValorTextBox1 = New System.Windows.Forms.TextBox()
        Me.Nom_ParteTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.LacteoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LacteoTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.LacteoTableAdapter()
        Me.ValorTextBox2 = New System.Windows.Forms.TextBox()
        Me.Tipo_LactTextBox = New System.Windows.Forms.TextBox()
        Me.QuesoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.QuesoTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.QuesoTableAdapter()
        Me.Tipo_QuesoTextBox = New System.Windows.Forms.TextBox()
        Me.ValorTextBox3 = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Carne_FriaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Carne_FriaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.Carne_FriaTableAdapter()
        Me.ValorTextBox4 = New System.Windows.Forms.TextBox()
        Me.Tipo_CarneTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.SalsaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.SalsaTableAdapter = New appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.SalsaTableAdapter()
        Me.ValorTextBox5 = New System.Windows.Forms.TextBox()
        Me.Tipo_SalsaTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        ValorLabel = New System.Windows.Forms.Label()
        Tipo_polloLabel = New System.Windows.Forms.Label()
        Tipo_ProductoLabel = New System.Windows.Forms.Label()
        IvaLabel = New System.Windows.Forms.Label()
        Referencia_ProductoLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        ActivoLabel = New System.Windows.Forms.Label()
        DescripciónLabel = New System.Windows.Forms.Label()
        Vlr_CompraLabel = New System.Windows.Forms.Label()
        Precio_VentaLabel = New System.Windows.Forms.Label()
        Fecha_IngresoLabel = New System.Windows.Forms.Label()
        Venta_PesoLabel = New System.Windows.Forms.Label()
        CantidadLabel = New System.Windows.Forms.Label()
        ValorLabel1 = New System.Windows.Forms.Label()
        Nom_ParteLabel = New System.Windows.Forms.Label()
        ValorLabel2 = New System.Windows.Forms.Label()
        Tipo_LactLabel = New System.Windows.Forms.Label()
        Tipo_QuesoLabel = New System.Windows.Forms.Label()
        ValorLabel3 = New System.Windows.Forms.Label()
        ValorLabel4 = New System.Windows.Forms.Label()
        Tipo_CarneLabel = New System.Windows.Forms.Label()
        ValorLabel5 = New System.Windows.Forms.Label()
        Tipo_SalsaLabel = New System.Windows.Forms.Label()
        CType(Me.BDD_Salsamentaria_1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.InventarioBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CategoriaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PolloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Parte_PolloBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.LacteoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.QuesoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.Carne_FriaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        CType(Me.SalsaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        Me.SuspendLayout()
        '
        'ValorLabel
        '
        ValorLabel.AutoSize = True
        ValorLabel.Location = New System.Drawing.Point(15, 22)
        ValorLabel.Name = "ValorLabel"
        ValorLabel.Size = New System.Drawing.Size(34, 13)
        ValorLabel.TabIndex = 2
        ValorLabel.Text = "Valor:"
        '
        'Tipo_polloLabel
        '
        Tipo_polloLabel.AutoSize = True
        Tipo_polloLabel.Location = New System.Drawing.Point(15, 48)
        Tipo_polloLabel.Name = "Tipo_polloLabel"
        Tipo_polloLabel.Size = New System.Drawing.Size(56, 13)
        Tipo_polloLabel.TabIndex = 4
        Tipo_polloLabel.Text = "Tipo pollo:"
        '
        'Tipo_ProductoLabel
        '
        Tipo_ProductoLabel.AutoSize = True
        Tipo_ProductoLabel.Location = New System.Drawing.Point(7, 26)
        Tipo_ProductoLabel.Name = "Tipo_ProductoLabel"
        Tipo_ProductoLabel.Size = New System.Drawing.Size(77, 13)
        Tipo_ProductoLabel.TabIndex = 10
        Tipo_ProductoLabel.Text = "Tipo Producto:"
        '
        'IvaLabel
        '
        IvaLabel.AutoSize = True
        IvaLabel.Location = New System.Drawing.Point(7, 52)
        IvaLabel.Name = "IvaLabel"
        IvaLabel.Size = New System.Drawing.Size(25, 13)
        IvaLabel.TabIndex = 12
        IvaLabel.Text = "Iva:"
        '
        'Referencia_ProductoLabel
        '
        Referencia_ProductoLabel.AutoSize = True
        Referencia_ProductoLabel.Location = New System.Drawing.Point(9, 20)
        Referencia_ProductoLabel.Name = "Referencia_ProductoLabel"
        Referencia_ProductoLabel.Size = New System.Drawing.Size(108, 13)
        Referencia_ProductoLabel.TabIndex = 24
        Referencia_ProductoLabel.Text = "Referencia Producto:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Location = New System.Drawing.Point(9, 46)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(47, 13)
        NombreLabel.TabIndex = 26
        NombreLabel.Text = "Nombre:"
        '
        'ActivoLabel
        '
        ActivoLabel.AutoSize = True
        ActivoLabel.Location = New System.Drawing.Point(9, 74)
        ActivoLabel.Name = "ActivoLabel"
        ActivoLabel.Size = New System.Drawing.Size(40, 13)
        ActivoLabel.TabIndex = 28
        ActivoLabel.Text = "Activo:"
        '
        'DescripciónLabel
        '
        DescripciónLabel.AutoSize = True
        DescripciónLabel.Location = New System.Drawing.Point(9, 102)
        DescripciónLabel.Name = "DescripciónLabel"
        DescripciónLabel.Size = New System.Drawing.Size(66, 13)
        DescripciónLabel.TabIndex = 30
        DescripciónLabel.Text = "Descripción:"
        '
        'Vlr_CompraLabel
        '
        Vlr_CompraLabel.AutoSize = True
        Vlr_CompraLabel.Location = New System.Drawing.Point(9, 128)
        Vlr_CompraLabel.Name = "Vlr_CompraLabel"
        Vlr_CompraLabel.Size = New System.Drawing.Size(60, 13)
        Vlr_CompraLabel.TabIndex = 32
        Vlr_CompraLabel.Text = "vlr Compra:"
        '
        'Precio_VentaLabel
        '
        Precio_VentaLabel.AutoSize = True
        Precio_VentaLabel.Location = New System.Drawing.Point(9, 154)
        Precio_VentaLabel.Name = "Precio_VentaLabel"
        Precio_VentaLabel.Size = New System.Drawing.Size(71, 13)
        Precio_VentaLabel.TabIndex = 34
        Precio_VentaLabel.Text = "Precio Venta:"
        '
        'Fecha_IngresoLabel
        '
        Fecha_IngresoLabel.AutoSize = True
        Fecha_IngresoLabel.Location = New System.Drawing.Point(9, 181)
        Fecha_IngresoLabel.Name = "Fecha_IngresoLabel"
        Fecha_IngresoLabel.Size = New System.Drawing.Size(78, 13)
        Fecha_IngresoLabel.TabIndex = 38
        Fecha_IngresoLabel.Text = "Fecha Ingreso:"
        '
        'Venta_PesoLabel
        '
        Venta_PesoLabel.AutoSize = True
        Venta_PesoLabel.Location = New System.Drawing.Point(9, 208)
        Venta_PesoLabel.Name = "Venta_PesoLabel"
        Venta_PesoLabel.Size = New System.Drawing.Size(65, 13)
        Venta_PesoLabel.TabIndex = 40
        Venta_PesoLabel.Text = "Venta Peso:"
        '
        'CantidadLabel
        '
        CantidadLabel.AutoSize = True
        CantidadLabel.Location = New System.Drawing.Point(9, 236)
        CantidadLabel.Name = "CantidadLabel"
        CantidadLabel.Size = New System.Drawing.Size(52, 13)
        CantidadLabel.TabIndex = 42
        CantidadLabel.Text = "Cantidad:"
        '
        'ValorLabel1
        '
        ValorLabel1.AutoSize = True
        ValorLabel1.Location = New System.Drawing.Point(24, 22)
        ValorLabel1.Name = "ValorLabel1"
        ValorLabel1.Size = New System.Drawing.Size(34, 13)
        ValorLabel1.TabIndex = 45
        ValorLabel1.Text = "Valor:"
        '
        'Nom_ParteLabel
        '
        Nom_ParteLabel.AutoSize = True
        Nom_ParteLabel.Location = New System.Drawing.Point(24, 48)
        Nom_ParteLabel.Name = "Nom_ParteLabel"
        Nom_ParteLabel.Size = New System.Drawing.Size(60, 13)
        Nom_ParteLabel.TabIndex = 47
        Nom_ParteLabel.Text = "Nom Parte:"
        '
        'BDD_Salsamentaria_1DataSet
        '
        Me.BDD_Salsamentaria_1DataSet.DataSetName = "BDD_Salsamentaria_1DataSet"
        Me.BDD_Salsamentaria_1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'InventarioBindingSource
        '
        Me.InventarioBindingSource.DataMember = "Inventario"
        Me.InventarioBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'InventarioTableAdapter
        '
        Me.InventarioTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.Carne_FriaTableAdapter = Nothing
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.Detalles_PedidoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.Inventario_ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.InventarioTableAdapter = Me.InventarioTableAdapter
        Me.TableAdapterManager.LacteoTableAdapter = Nothing
        Me.TableAdapterManager.Parte_PolloTableAdapter = Nothing
        Me.TableAdapterManager.PolloTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.QuesoTableAdapter = Nothing
        Me.TableAdapterManager.RolTableAdapter = Nothing
        Me.TableAdapterManager.SalsaTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = appSalsamentaria.BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.Usuario_RolTableAdapter = Nothing
        Me.TableAdapterManager.UsuarioTableAdapter = Nothing
        '
        'CategoriaBindingSource
        '
        Me.CategoriaBindingSource.DataMember = "Categoria"
        Me.CategoriaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'CategoriaTableAdapter
        '
        Me.CategoriaTableAdapter.ClearBeforeFill = True
        '
        'PolloBindingSource
        '
        Me.PolloBindingSource.DataMember = "Pollo"
        Me.PolloBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'PolloTableAdapter
        '
        Me.PolloTableAdapter.ClearBeforeFill = True
        '
        'ValorTextBox
        '
        Me.ValorTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PolloBindingSource, "Valor", True))
        Me.ValorTextBox.Location = New System.Drawing.Point(90, 19)
        Me.ValorTextBox.Name = "ValorTextBox"
        Me.ValorTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox.TabIndex = 3
        '
        'Tipo_polloTextBox
        '
        Me.Tipo_polloTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PolloBindingSource, "Tipo_pollo", True))
        Me.Tipo_polloTextBox.Location = New System.Drawing.Point(90, 45)
        Me.Tipo_polloTextBox.Name = "Tipo_polloTextBox"
        Me.Tipo_polloTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_polloTextBox.TabIndex = 5
        '
        'Tipo_ProductoTextBox
        '
        Me.Tipo_ProductoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CategoriaBindingSource, "Tipo_Producto", True))
        Me.Tipo_ProductoTextBox.Location = New System.Drawing.Point(90, 23)
        Me.Tipo_ProductoTextBox.Name = "Tipo_ProductoTextBox"
        Me.Tipo_ProductoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_ProductoTextBox.TabIndex = 11
        '
        'IvaTextBox
        '
        Me.IvaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CategoriaBindingSource, "Iva", True))
        Me.IvaTextBox.Location = New System.Drawing.Point(90, 49)
        Me.IvaTextBox.Name = "IvaTextBox"
        Me.IvaTextBox.Size = New System.Drawing.Size(100, 20)
        Me.IvaTextBox.TabIndex = 13
        '
        'Referencia_ProductoTextBox
        '
        Me.Referencia_ProductoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Referencia_Producto", True))
        Me.Referencia_ProductoTextBox.Location = New System.Drawing.Point(123, 17)
        Me.Referencia_ProductoTextBox.Name = "Referencia_ProductoTextBox"
        Me.Referencia_ProductoTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Referencia_ProductoTextBox.TabIndex = 25
        '
        'NombreTextBox
        '
        Me.NombreTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Nombre", True))
        Me.NombreTextBox.Location = New System.Drawing.Point(123, 43)
        Me.NombreTextBox.Name = "NombreTextBox"
        Me.NombreTextBox.Size = New System.Drawing.Size(200, 20)
        Me.NombreTextBox.TabIndex = 27
        '
        'ActivoCheckBox
        '
        Me.ActivoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.InventarioBindingSource, "Activo", True))
        Me.ActivoCheckBox.Location = New System.Drawing.Point(123, 69)
        Me.ActivoCheckBox.Name = "ActivoCheckBox"
        Me.ActivoCheckBox.Size = New System.Drawing.Size(200, 24)
        Me.ActivoCheckBox.TabIndex = 29
        Me.ActivoCheckBox.Text = "CheckBox1"
        Me.ActivoCheckBox.UseVisualStyleBackColor = True
        '
        'DescripciónTextBox
        '
        Me.DescripciónTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Descripción", True))
        Me.DescripciónTextBox.Location = New System.Drawing.Point(123, 99)
        Me.DescripciónTextBox.Name = "DescripciónTextBox"
        Me.DescripciónTextBox.Size = New System.Drawing.Size(200, 20)
        Me.DescripciónTextBox.TabIndex = 31
        '
        'Vlr_CompraTextBox
        '
        Me.Vlr_CompraTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "vlr_Compra", True))
        Me.Vlr_CompraTextBox.Location = New System.Drawing.Point(123, 125)
        Me.Vlr_CompraTextBox.Name = "Vlr_CompraTextBox"
        Me.Vlr_CompraTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Vlr_CompraTextBox.TabIndex = 33
        '
        'Precio_VentaTextBox
        '
        Me.Precio_VentaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Precio_Venta", True))
        Me.Precio_VentaTextBox.Location = New System.Drawing.Point(123, 151)
        Me.Precio_VentaTextBox.Name = "Precio_VentaTextBox"
        Me.Precio_VentaTextBox.Size = New System.Drawing.Size(200, 20)
        Me.Precio_VentaTextBox.TabIndex = 35
        '
        'Fecha_IngresoDateTimePicker
        '
        Me.Fecha_IngresoDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.InventarioBindingSource, "Fecha_Ingreso", True))
        Me.Fecha_IngresoDateTimePicker.Location = New System.Drawing.Point(123, 177)
        Me.Fecha_IngresoDateTimePicker.Name = "Fecha_IngresoDateTimePicker"
        Me.Fecha_IngresoDateTimePicker.Size = New System.Drawing.Size(200, 20)
        Me.Fecha_IngresoDateTimePicker.TabIndex = 39
        '
        'Venta_PesoCheckBox
        '
        Me.Venta_PesoCheckBox.DataBindings.Add(New System.Windows.Forms.Binding("CheckState", Me.InventarioBindingSource, "Venta_Peso", True))
        Me.Venta_PesoCheckBox.Location = New System.Drawing.Point(123, 203)
        Me.Venta_PesoCheckBox.Name = "Venta_PesoCheckBox"
        Me.Venta_PesoCheckBox.Size = New System.Drawing.Size(200, 24)
        Me.Venta_PesoCheckBox.TabIndex = 41
        Me.Venta_PesoCheckBox.Text = "CheckBox1"
        Me.Venta_PesoCheckBox.UseVisualStyleBackColor = True
        '
        'CantidadTextBox
        '
        Me.CantidadTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.InventarioBindingSource, "Cantidad", True))
        Me.CantidadTextBox.Location = New System.Drawing.Point(123, 233)
        Me.CantidadTextBox.Name = "CantidadTextBox"
        Me.CantidadTextBox.Size = New System.Drawing.Size(200, 20)
        Me.CantidadTextBox.TabIndex = 43
        '
        'Parte_PolloBindingSource
        '
        Me.Parte_PolloBindingSource.DataMember = "Parte_Pollo"
        Me.Parte_PolloBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'Parte_PolloTableAdapter
        '
        Me.Parte_PolloTableAdapter.ClearBeforeFill = True
        '
        'ValorTextBox1
        '
        Me.ValorTextBox1.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Parte_PolloBindingSource, "Valor", True))
        Me.ValorTextBox1.Location = New System.Drawing.Point(90, 19)
        Me.ValorTextBox1.Name = "ValorTextBox1"
        Me.ValorTextBox1.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox1.TabIndex = 46
        '
        'Nom_ParteTextBox
        '
        Me.Nom_ParteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Parte_PolloBindingSource, "Nom_Parte", True))
        Me.Nom_ParteTextBox.Location = New System.Drawing.Point(90, 45)
        Me.Nom_ParteTextBox.Name = "Nom_ParteTextBox"
        Me.Nom_ParteTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Nom_ParteTextBox.TabIndex = 48
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Referencia_ProductoLabel)
        Me.GroupBox1.Controls.Add(Me.Referencia_ProductoTextBox)
        Me.GroupBox1.Controls.Add(NombreLabel)
        Me.GroupBox1.Controls.Add(Me.NombreTextBox)
        Me.GroupBox1.Controls.Add(ActivoLabel)
        Me.GroupBox1.Controls.Add(Me.ActivoCheckBox)
        Me.GroupBox1.Controls.Add(DescripciónLabel)
        Me.GroupBox1.Controls.Add(Me.DescripciónTextBox)
        Me.GroupBox1.Controls.Add(Vlr_CompraLabel)
        Me.GroupBox1.Controls.Add(Me.Vlr_CompraTextBox)
        Me.GroupBox1.Controls.Add(Precio_VentaLabel)
        Me.GroupBox1.Controls.Add(Me.Precio_VentaTextBox)
        Me.GroupBox1.Controls.Add(Fecha_IngresoLabel)
        Me.GroupBox1.Controls.Add(Me.Fecha_IngresoDateTimePicker)
        Me.GroupBox1.Controls.Add(Venta_PesoLabel)
        Me.GroupBox1.Controls.Add(Me.Venta_PesoCheckBox)
        Me.GroupBox1.Controls.Add(CantidadLabel)
        Me.GroupBox1.Controls.Add(Me.CantidadTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(345, 283)
        Me.GroupBox1.TabIndex = 49
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Inventario"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Tipo_ProductoLabel)
        Me.GroupBox2.Controls.Add(Me.Tipo_ProductoTextBox)
        Me.GroupBox2.Controls.Add(IvaLabel)
        Me.GroupBox2.Controls.Add(Me.IvaTextBox)
        Me.GroupBox2.Location = New System.Drawing.Point(363, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(227, 80)
        Me.GroupBox2.TabIndex = 50
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Categoria"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(ValorLabel)
        Me.GroupBox3.Controls.Add(Me.ValorTextBox)
        Me.GroupBox3.Controls.Add(Tipo_polloLabel)
        Me.GroupBox3.Controls.Add(Me.Tipo_polloTextBox)
        Me.GroupBox3.Location = New System.Drawing.Point(363, 98)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(227, 81)
        Me.GroupBox3.TabIndex = 51
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Pollo"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(ValorLabel1)
        Me.GroupBox4.Controls.Add(Me.ValorTextBox1)
        Me.GroupBox4.Controls.Add(Nom_ParteLabel)
        Me.GroupBox4.Controls.Add(Me.Nom_ParteTextBox)
        Me.GroupBox4.Location = New System.Drawing.Point(363, 185)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(227, 81)
        Me.GroupBox4.TabIndex = 52
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Partes_Pollo"
        '
        'LacteoBindingSource
        '
        Me.LacteoBindingSource.DataMember = "Lacteo"
        Me.LacteoBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'LacteoTableAdapter
        '
        Me.LacteoTableAdapter.ClearBeforeFill = True
        '
        'ValorLabel2
        '
        ValorLabel2.AutoSize = True
        ValorLabel2.Location = New System.Drawing.Point(30, 22)
        ValorLabel2.Name = "ValorLabel2"
        ValorLabel2.Size = New System.Drawing.Size(34, 13)
        ValorLabel2.TabIndex = 54
        ValorLabel2.Text = "Valor:"
        '
        'ValorTextBox2
        '
        Me.ValorTextBox2.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.LacteoBindingSource, "Valor", True))
        Me.ValorTextBox2.Location = New System.Drawing.Point(91, 19)
        Me.ValorTextBox2.Name = "ValorTextBox2"
        Me.ValorTextBox2.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox2.TabIndex = 55
        '
        'Tipo_LactLabel
        '
        Tipo_LactLabel.AutoSize = True
        Tipo_LactLabel.Location = New System.Drawing.Point(30, 48)
        Tipo_LactLabel.Name = "Tipo_LactLabel"
        Tipo_LactLabel.Size = New System.Drawing.Size(55, 13)
        Tipo_LactLabel.TabIndex = 56
        Tipo_LactLabel.Text = "Tipo Lact:"
        '
        'Tipo_LactTextBox
        '
        Me.Tipo_LactTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.LacteoBindingSource, "Tipo_Lact", True))
        Me.Tipo_LactTextBox.Location = New System.Drawing.Point(91, 45)
        Me.Tipo_LactTextBox.Name = "Tipo_LactTextBox"
        Me.Tipo_LactTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_LactTextBox.TabIndex = 57
        '
        'QuesoBindingSource
        '
        Me.QuesoBindingSource.DataMember = "Queso"
        Me.QuesoBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'QuesoTableAdapter
        '
        Me.QuesoTableAdapter.ClearBeforeFill = True
        '
        'Tipo_QuesoLabel
        '
        Tipo_QuesoLabel.AutoSize = True
        Tipo_QuesoLabel.Location = New System.Drawing.Point(20, 48)
        Tipo_QuesoLabel.Name = "Tipo_QuesoLabel"
        Tipo_QuesoLabel.Size = New System.Drawing.Size(65, 13)
        Tipo_QuesoLabel.TabIndex = 59
        Tipo_QuesoLabel.Text = "Tipo Queso:"
        '
        'Tipo_QuesoTextBox
        '
        Me.Tipo_QuesoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QuesoBindingSource, "Tipo_Queso", True))
        Me.Tipo_QuesoTextBox.Location = New System.Drawing.Point(91, 45)
        Me.Tipo_QuesoTextBox.Name = "Tipo_QuesoTextBox"
        Me.Tipo_QuesoTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_QuesoTextBox.TabIndex = 60
        '
        'ValorLabel3
        '
        ValorLabel3.AutoSize = True
        ValorLabel3.Location = New System.Drawing.Point(20, 22)
        ValorLabel3.Name = "ValorLabel3"
        ValorLabel3.Size = New System.Drawing.Size(34, 13)
        ValorLabel3.TabIndex = 61
        ValorLabel3.Text = "Valor:"
        '
        'ValorTextBox3
        '
        Me.ValorTextBox3.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.QuesoBindingSource, "Valor", True))
        Me.ValorTextBox3.Location = New System.Drawing.Point(91, 19)
        Me.ValorTextBox3.Name = "ValorTextBox3"
        Me.ValorTextBox3.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox3.TabIndex = 62
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(ValorLabel2)
        Me.GroupBox5.Controls.Add(Me.ValorTextBox2)
        Me.GroupBox5.Controls.Add(Tipo_LactLabel)
        Me.GroupBox5.Controls.Add(Me.Tipo_LactTextBox)
        Me.GroupBox5.Location = New System.Drawing.Point(596, 12)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(227, 80)
        Me.GroupBox5.TabIndex = 63
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Lacteo"
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Tipo_QuesoLabel)
        Me.GroupBox6.Controls.Add(Me.Tipo_QuesoTextBox)
        Me.GroupBox6.Controls.Add(ValorLabel3)
        Me.GroupBox6.Controls.Add(Me.ValorTextBox3)
        Me.GroupBox6.Location = New System.Drawing.Point(596, 98)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(227, 81)
        Me.GroupBox6.TabIndex = 64
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Queso"
        '
        'Carne_FriaBindingSource
        '
        Me.Carne_FriaBindingSource.DataMember = "Carne_Fria"
        Me.Carne_FriaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'Carne_FriaTableAdapter
        '
        Me.Carne_FriaTableAdapter.ClearBeforeFill = True
        '
        'ValorLabel4
        '
        ValorLabel4.AutoSize = True
        ValorLabel4.Location = New System.Drawing.Point(23, 23)
        ValorLabel4.Name = "ValorLabel4"
        ValorLabel4.Size = New System.Drawing.Size(34, 13)
        ValorLabel4.TabIndex = 66
        ValorLabel4.Text = "Valor:"
        '
        'ValorTextBox4
        '
        Me.ValorTextBox4.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Carne_FriaBindingSource, "Valor", True))
        Me.ValorTextBox4.Location = New System.Drawing.Point(91, 20)
        Me.ValorTextBox4.Name = "ValorTextBox4"
        Me.ValorTextBox4.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox4.TabIndex = 67
        '
        'Tipo_CarneLabel
        '
        Tipo_CarneLabel.AutoSize = True
        Tipo_CarneLabel.Location = New System.Drawing.Point(23, 49)
        Tipo_CarneLabel.Name = "Tipo_CarneLabel"
        Tipo_CarneLabel.Size = New System.Drawing.Size(62, 13)
        Tipo_CarneLabel.TabIndex = 68
        Tipo_CarneLabel.Text = "Tipo Carne:"
        '
        'Tipo_CarneTextBox
        '
        Me.Tipo_CarneTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.Carne_FriaBindingSource, "Tipo_Carne", True))
        Me.Tipo_CarneTextBox.Location = New System.Drawing.Point(91, 46)
        Me.Tipo_CarneTextBox.Name = "Tipo_CarneTextBox"
        Me.Tipo_CarneTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_CarneTextBox.TabIndex = 69
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(ValorLabel4)
        Me.GroupBox7.Controls.Add(Me.ValorTextBox4)
        Me.GroupBox7.Controls.Add(Tipo_CarneLabel)
        Me.GroupBox7.Controls.Add(Me.Tipo_CarneTextBox)
        Me.GroupBox7.Location = New System.Drawing.Point(596, 185)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(227, 81)
        Me.GroupBox7.TabIndex = 70
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Carne_Fria"
        '
        'SalsaBindingSource
        '
        Me.SalsaBindingSource.DataMember = "Salsa"
        Me.SalsaBindingSource.DataSource = Me.BDD_Salsamentaria_1DataSet
        '
        'SalsaTableAdapter
        '
        Me.SalsaTableAdapter.ClearBeforeFill = True
        '
        'ValorLabel5
        '
        ValorLabel5.AutoSize = True
        ValorLabel5.Location = New System.Drawing.Point(25, 22)
        ValorLabel5.Name = "ValorLabel5"
        ValorLabel5.Size = New System.Drawing.Size(34, 13)
        ValorLabel5.TabIndex = 72
        ValorLabel5.Text = "Valor:"
        '
        'ValorTextBox5
        '
        Me.ValorTextBox5.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SalsaBindingSource, "Valor", True))
        Me.ValorTextBox5.Location = New System.Drawing.Point(91, 19)
        Me.ValorTextBox5.Name = "ValorTextBox5"
        Me.ValorTextBox5.Size = New System.Drawing.Size(100, 20)
        Me.ValorTextBox5.TabIndex = 73
        '
        'Tipo_SalsaLabel
        '
        Tipo_SalsaLabel.AutoSize = True
        Tipo_SalsaLabel.Location = New System.Drawing.Point(25, 48)
        Tipo_SalsaLabel.Name = "Tipo_SalsaLabel"
        Tipo_SalsaLabel.Size = New System.Drawing.Size(60, 13)
        Tipo_SalsaLabel.TabIndex = 74
        Tipo_SalsaLabel.Text = "Tipo Salsa:"
        '
        'Tipo_SalsaTextBox
        '
        Me.Tipo_SalsaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.SalsaBindingSource, "Tipo_Salsa", True))
        Me.Tipo_SalsaTextBox.Location = New System.Drawing.Point(91, 45)
        Me.Tipo_SalsaTextBox.Name = "Tipo_SalsaTextBox"
        Me.Tipo_SalsaTextBox.Size = New System.Drawing.Size(100, 20)
        Me.Tipo_SalsaTextBox.TabIndex = 75
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(ValorLabel5)
        Me.GroupBox8.Controls.Add(Me.ValorTextBox5)
        Me.GroupBox8.Controls.Add(Tipo_SalsaLabel)
        Me.GroupBox8.Controls.Add(Me.Tipo_SalsaTextBox)
        Me.GroupBox8.Location = New System.Drawing.Point(829, 12)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(227, 73)
        Me.GroupBox8.TabIndex = 76
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Salsa"
        '
        'Inventario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 729)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox7)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Inventario"
        Me.Text = "Inventario"
        CType(Me.BDD_Salsamentaria_1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.InventarioBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CategoriaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PolloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Parte_PolloBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        CType(Me.LacteoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.QuesoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.Carne_FriaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        CType(Me.SalsaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BDD_Salsamentaria_1DataSet As BDD_Salsamentaria_1DataSet
    Friend WithEvents InventarioBindingSource As BindingSource
    Friend WithEvents InventarioTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.InventarioTableAdapter
    Friend WithEvents TableAdapterManager As BDD_Salsamentaria_1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents CategoriaBindingSource As BindingSource
    Friend WithEvents CategoriaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.CategoriaTableAdapter
    Friend WithEvents PolloBindingSource As BindingSource
    Friend WithEvents PolloTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.PolloTableAdapter
    Friend WithEvents ValorTextBox As TextBox
    Friend WithEvents Tipo_polloTextBox As TextBox
    Friend WithEvents Tipo_ProductoTextBox As TextBox
    Friend WithEvents IvaTextBox As TextBox
    Friend WithEvents Referencia_ProductoTextBox As TextBox
    Friend WithEvents NombreTextBox As TextBox
    Friend WithEvents ActivoCheckBox As CheckBox
    Friend WithEvents DescripciónTextBox As TextBox
    Friend WithEvents Vlr_CompraTextBox As TextBox
    Friend WithEvents Precio_VentaTextBox As TextBox
    Friend WithEvents Fecha_IngresoDateTimePicker As DateTimePicker
    Friend WithEvents Venta_PesoCheckBox As CheckBox
    Friend WithEvents CantidadTextBox As TextBox
    Friend WithEvents Parte_PolloBindingSource As BindingSource
    Friend WithEvents Parte_PolloTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.Parte_PolloTableAdapter
    Friend WithEvents ValorTextBox1 As TextBox
    Friend WithEvents Nom_ParteTextBox As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents LacteoBindingSource As BindingSource
    Friend WithEvents LacteoTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.LacteoTableAdapter
    Friend WithEvents ValorTextBox2 As TextBox
    Friend WithEvents Tipo_LactTextBox As TextBox
    Friend WithEvents QuesoBindingSource As BindingSource
    Friend WithEvents QuesoTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.QuesoTableAdapter
    Friend WithEvents Tipo_QuesoTextBox As TextBox
    Friend WithEvents ValorTextBox3 As TextBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents Carne_FriaBindingSource As BindingSource
    Friend WithEvents Carne_FriaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.Carne_FriaTableAdapter
    Friend WithEvents ValorTextBox4 As TextBox
    Friend WithEvents Tipo_CarneTextBox As TextBox
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents SalsaBindingSource As BindingSource
    Friend WithEvents SalsaTableAdapter As BDD_Salsamentaria_1DataSetTableAdapters.SalsaTableAdapter
    Friend WithEvents ValorTextBox5 As TextBox
    Friend WithEvents Tipo_SalsaTextBox As TextBox
    Friend WithEvents GroupBox8 As GroupBox
End Class
