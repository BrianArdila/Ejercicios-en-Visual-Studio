﻿Public Class Panel_Principal
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles UsuariosBTT.Click
        'Redirige o  abre un form 
        Usuarios.Show()
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub SalirBTT_Click(sender As Object, e As EventArgs) Handles SalirBTT.Click
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub ProveedorBTT_Click(sender As Object, e As EventArgs) Handles ProveedorBTT.Click
        'Redirige o  abre un form 
        Proveedor.Show()
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub ClienteBTT_Click(sender As Object, e As EventArgs) Handles ClienteBTT.Click
        'Redirige o  abre un form 
        Cliente.Show()
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub FacturaBTT_Click(sender As Object, e As EventArgs) Handles FacturaBTT.Click
        'Redirige o  abre un form 
        Factura.Show()
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub InventarioBTT_Click(sender As Object, e As EventArgs) Handles InventarioBTT.Click
        'Redirige o  abre un form 
        Inventario.Show()
        'Cierra el form
        Me.Close()
    End Sub

    Private Sub Panel_Principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class