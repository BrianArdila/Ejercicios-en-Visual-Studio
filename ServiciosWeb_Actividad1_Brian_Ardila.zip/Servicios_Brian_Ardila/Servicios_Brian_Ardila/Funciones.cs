﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Servicios_Brian_Ardila
{
    public class Funciones
    {
         public static void Logs(string Nombre, string Descripcion)
         {
            string directorio = AppDomain.CurrentDomain.BaseDirectory 
                + "Logs"
                + DateTime.Now.Year.ToString()
                + DateTime.Now.Month.ToString()
                + DateTime.Now.Day.ToString();
            if (!Directory.Exists(directorio))
            {
                Directory.CreateDirectory(directorio);
            }

            string RutaDirectorio = directorio + "/" + Nombre + ".txt";
            StreamWriter fileLog = new StreamWriter(RutaDirectorio, true);
            string cadena = DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss")
                + ">>>" + Descripcion;
            fileLog.WriteLine(cadena);
            fileLog.Close();
         }
    }
}