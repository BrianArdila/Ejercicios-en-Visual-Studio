﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Servicios_Brian_Ardila
{
    /// <summary>
    /// Descripción breve de WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos, este es mi primer servicio web";
        }

        [WebMethod(Description = "Saluda a una persona")]
        public string Saludar(string nombre)
        {
            return "Hola " + nombre;
        }

        [WebMethod(Description = "Registra un mensaje")]
        public string GuardarLog(string Mensaje)
        {
            Funciones.Logs("LogServicios", Mensaje);
            return "ok";
        }
    }
}
