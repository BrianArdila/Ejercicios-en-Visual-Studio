﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumosBrian_Ardila
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.WebService1SoapClient client = new ServiceReference1.WebService1SoapClient();
            string resultado1 = client.HelloWorld();
            Console.WriteLine(resultado1);

            string resultado2 = client.Saludar("Brian");
            Console.WriteLine(resultado2);

            string prueba = client.GuardarLog("Probando Si funciono o que .....");
            Console.WriteLine(prueba);

            Console.WriteLine("Presione cualquier tecla para terminar");
            Console.ReadKey();
        }
    }
}
